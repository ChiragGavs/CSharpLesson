﻿namespace NWindMVCApp.Models
{
    public class RepositoryEmployee
    {
        public NorthwindContext _context;
        public RepositoryEmployee(NorthwindContext context)
        {
            _context = context;
        }
        public List<Employee> AllEmployee()
        {
            return _context.Employees.ToList();
        }   
    }
}
