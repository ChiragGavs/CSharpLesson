﻿namespace NWindMVCApp.Models
{
    public class RepositoyOrder
    {
        public NorthwindContext _context;
        public RepositoyOrder(NorthwindContext context)
        {
            _context = context;
        }
        public List<Order> GetOrders()
        {
            return _context.Orders.ToList();
        }
        public Order PutOrder(int id) 
        {
            Console.WriteLine($"searching id: {id}");
            Order order = _context.Orders.Find(id);
            return order;
        }
    }
}
